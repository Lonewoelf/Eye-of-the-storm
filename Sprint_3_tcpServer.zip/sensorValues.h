#pragma once

class sensorValues {

private:
	int temperature;
	int humidity;
	int windSpeed;
	std::string windDirection;

public:


};